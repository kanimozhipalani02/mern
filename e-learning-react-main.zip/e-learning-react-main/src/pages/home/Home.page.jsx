import React from 'react';
import HomeComponent from '../../components/home/Home.component';

const HomePage = () => {
  return (
    <>
      <HomeComponent />
    </>
  );
};

export default HomePage;
