import React from 'react';
import LibMaterial from '../../components/lib-material/LibMaterial.component';

const MaterialsPage = () => {
  return (
    <>
      <LibMaterial />
    </>
  );
};

export default MaterialsPage;
